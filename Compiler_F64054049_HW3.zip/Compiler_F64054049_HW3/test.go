var x int32 = 10

for x > 0 {

	x--
}