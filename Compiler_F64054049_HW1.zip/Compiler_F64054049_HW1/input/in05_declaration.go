var x float32
var y_000 int32 = 5
var __z string = "OuO"
var weight bool = false