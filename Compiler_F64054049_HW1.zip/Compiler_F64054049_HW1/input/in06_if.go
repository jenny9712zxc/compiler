if x > abcd {
	x++
} 