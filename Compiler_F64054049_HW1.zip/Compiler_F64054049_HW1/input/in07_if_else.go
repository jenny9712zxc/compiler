if x > qwe {
	x++
} else {
    x--
}